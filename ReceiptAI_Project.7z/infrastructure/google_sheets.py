def save_invoice(invoice):
    """
    模擬將資料存入 Google Sheet
    """
    print(f"Saving invoice {invoice.number}, total {invoice.total} to Google Sheet")
